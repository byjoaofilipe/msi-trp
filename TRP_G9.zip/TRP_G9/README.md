# Projeto de TRP

Este arquivo contém todos os artifactos técnicos, dados e documentação desenvolvidos no âmbito do projeto de TRP.

## Estrutura do Arquivo

* **`dataset/`**: Contém os conjuntos de dados utilizados no projeto (incluindo o *dataset* original, a versão sanitizada e os resultados anonimizados exportados do ARX).
* **`hierarquias/`**: Ficheiros CSV com as árvores de generalização criadas para os atributos Quase-Identificadores (QIDs), prontos a importar para o ARX.
* **`scripts/`**: Código Python desenvolvido para pré-processamento, análise estatística e automação de gráficos.
* **`relatorio_G9.pdf`**: Relatório Final.

